<!--footer-->
    <div class="footer">
       <p>&copy;  BSMS Admin Panel.</p>
    </div>
        <!--//footer-->